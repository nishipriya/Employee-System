# Employee-Management-System


An application allows non-developers to view and interact with information stored in databases for managing a company's employees (using node, inquirer, and MySQL), often referred to as Content Management Systems.
This was built using Inquirer, MySQL, and Node.
